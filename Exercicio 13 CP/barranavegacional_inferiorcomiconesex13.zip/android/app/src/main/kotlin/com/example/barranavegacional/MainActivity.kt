package com.example.barranavegacional

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
