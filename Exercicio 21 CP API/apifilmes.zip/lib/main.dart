import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() => runApp(FilmeApp());

class Filme {
  final String nome;
  final String sinopse;
  final String foto;

  Filme({required this.nome, required this.sinopse, required this.foto});

  factory Filme.fromJson(Map<String, dynamic> json) {
    return Filme(
      nome: json['nome'] as String,
      sinopse: json['sinopse'] as String,
      foto: json['foto'] as String,
    );
  }
}

class FilmeService {
  Future<List<Filme>> fetchFilmes() async {
    try {
      final response = await http
          .get(Uri.parse('https://sujeitoprogramador.com/r-api/?api=filmes'));
      if (response.statusCode == 200) {
        Iterable json = jsonDecode(response.body) as Iterable;
        return List<Filme>.from(json.map((model) => Filme.fromJson(model)));
      } else {
        throw Exception('Falha ao carregar filmes');
      }
    } catch (e) {
      throw Exception('Erro ao buscar filmes: $e');
    }
  }
}

class FilmeApp extends StatelessWidget {
  final FilmeService filmeService = FilmeService();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blueGrey[900],
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('API de Filmes'),
              const SizedBox(width: 10),
              Image.network(
                'https://upload.wikimedia.org/wikipedia/commons/6/69/IMDB_Logo_2016.svg',
                height: 20,
              ),
            ],
          ),
          centerTitle: true,
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 8.0, bottom: 8.0),
              child: const Text(
                'LISTA DE FILMES',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ),
            Expanded(
              child: FutureBuilder<List<Filme>>(
                future: filmeService.fetchFilmes(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  } else if (snapshot.hasError) {
                    return Text('Erro: ${snapshot.error}');
                  } else if (snapshot.hasData) {
                    final filmes = snapshot.data!;
                    return Padding(
                      padding: const EdgeInsets.all(8),
                      child: ListView.builder(
                        itemCount: filmes.length,
                        itemBuilder: (context, index) {
                          final filme = filmes[index];
                          return Container(
                            margin: const EdgeInsets.symmetric(vertical: 8),
                            decoration: BoxDecoration(
                              border: Border.all(
                                  color: Colors.blueGrey[900]!, width: 2),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: ListTile(
                              leading: ClipRRect(
                                borderRadius: BorderRadius.circular(8.0),
                                child: Image.network(
                                  filme.foto,
                                  width: 100.0,
                                  height: 150.0,
                                ),
                              ),
                              title: Text(
                                filme.nome,
                                style: const TextStyle(fontSize: 18),
                              ),
                              trailing: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  primary: Colors.blueGrey[900],
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(18.0),
                                  ),
                                ),
                                onPressed: () {
                                  Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          FilmeDetalhes(filme: filme),
                                    ),
                                  );
                                },
                                child: const Text('Ler mais'),
                              ),
                            ),
                          );
                        },
                      ),
                    );
                  } else {
                    return const Text('Nenhum dado encontrado.');
                  }
                },
              ),
            ),
            Container(
              padding: const EdgeInsets.all(10.0),
              child: const Text(
                'Alunos FIAP 2023',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}

class FilmeDetalhes extends StatelessWidget {
  final Filme filme;

  FilmeDetalhes({required this.filme});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(filme.nome),
        backgroundColor: Colors.blueGrey[900],
      ),
      body: Column(
        children: [
          Image.network(filme.foto),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(filme.sinopse),
          ),
        ],
      ),
    );
  }
}
