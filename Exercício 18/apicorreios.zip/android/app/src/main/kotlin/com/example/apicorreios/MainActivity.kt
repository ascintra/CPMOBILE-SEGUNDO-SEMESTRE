package com.example.apicorreios

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
