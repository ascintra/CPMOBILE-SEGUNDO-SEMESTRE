package com.example.anunciodevagasex09

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
