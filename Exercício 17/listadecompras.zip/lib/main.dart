import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Inicialize o banco de dados e o passe para o aplicativo
  final database = await openDatabase(
    'shopping_list.db',
    version: 1,
    onCreate: (db, version) {
      return db.execute(
        'CREATE TABLE shopping_items(id INTEGER PRIMARY KEY, merchandise TEXT, quantity INTEGER, complete INTEGER)',
      );
    },
  );

  runApp(MyApp(database: database));
}

class MyApp extends StatelessWidget {
  final Database database;

  MyApp({Key? key, required this.database}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shopping List App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(database: database),
    );
  }
}

class MyHomePage extends StatefulWidget {
  final Database database;

  MyHomePage({Key? key, required this.database}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<ShoppingItem> shoppingItems = [];

  @override
  void initState() {
    super.initState();
    _loadShoppingItems();
  }

  Future<void> _loadShoppingItems() async {
    final List<Map<String, dynamic>> maps =
        await widget.database.query('shopping_items');

    setState(() {
      shoppingItems = List.generate(maps.length, (i) {
        return ShoppingItem(
          id: maps[i]['id'],
          merchandise: maps[i]['merchandise'],
          quantity: maps[i]['quantity'],
          complete: maps[i]['complete'] == 1,
        );
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Shopping List'),
      ),
      body: ListView.builder(
        itemCount: shoppingItems.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(
                '${shoppingItems[index].merchandise} - ${shoppingItems[index].quantity}'),
            leading: Icon(
              shoppingItems[index].complete
                  ? Icons.check_box
                  : Icons.check_box_outline_blank,
            ),
            onTap: () {
              setState(() {
                shoppingItems[index].complete = !shoppingItems[index].complete;
              });
              widget.database.update(
                'shopping_items',
                {'complete': shoppingItems[index].complete ? 1 : 0},
                where: 'id = ?',
                whereArgs: [shoppingItems[index].id],
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          var id = await showDialog<int>(
            context: context,
            builder: (context) {
              return AddShoppingItemDialog(database: widget.database);
            },
          );
          if (id != null) {
            _loadShoppingItems();
          }
        },
        tooltip: 'Add Item',
        child: Icon(Icons.add),
      ),
    );
  }
}

class ShoppingItem {
  int id;
  String merchandise;
  int quantity;
  bool complete;

  ShoppingItem({
    required this.id,
    required this.merchandise,
    required this.quantity,
    required this.complete,
  });
}

class AddShoppingItemDialog extends StatefulWidget {
  final Database database;

  AddShoppingItemDialog({required this.database});

  @override
  _AddShoppingItemDialogState createState() => _AddShoppingItemDialogState();
}

class _AddShoppingItemDialogState extends State<AddShoppingItemDialog> {
  TextEditingController merchandiseController = TextEditingController();
  TextEditingController quantityController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Add a new shopping item'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            TextField(
              controller: merchandiseController,
              decoration: InputDecoration(hintText: 'Enter merchandise'),
            ),
            TextField(
              controller: quantityController,
              decoration: InputDecoration(hintText: 'Enter quantity'),
              keyboardType: TextInputType.numberWithOptions(decimal: false),
            ),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          child: Text('CANCEL'),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        TextButton(
          child: Text('SAVE'),
          onPressed: () async {
            final String merchandise = merchandiseController.text;
            final int? quantity = int.tryParse(quantityController.text);
            if (merchandise.isNotEmpty && quantity != null) {
              await widget.database.insert(
                'shopping_items',
                {
                  'merchandise': merchandise,
                  'quantity': quantity,
                  'complete': 0,
                },
              );
              Navigator.of(context).pop();
            }
          },
        ),
      ],
    );
  }
}
