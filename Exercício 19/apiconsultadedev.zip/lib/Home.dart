import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  TextEditingController textController = TextEditingController();
  int github_id = 0;
  String github_nome = '';
  int github_repos = 0;
  int github_followers = 0;
  int github_following = 0;
  String github_created = '';
  String github_avatar =
      'https://th.bing.com/th/id/OIP.eTCbdR_AFzbqHMPXhrJWUQHaEK?pid=ImgDet&rs=1';
  List<String> repoNames = [];
  List<String> repoUrls = [];

  _getUserData() async {
    String url = 'https://api.github.com/users/${textController.text}';
    http.Response response = await http.get(Uri.parse(url));
    Map<String, dynamic> retorno = json.decode(response.body);
    setState(() {
      github_id = retorno['id'];
      github_nome = retorno['name'];
      github_created = retorno['created_at'];
      github_avatar = retorno['avatar_url'];
    });
    await _getUserRepos();
  }

  _getUserRepos() async {
    String url = 'https://api.github.com/users/${textController.text}/repos';
    http.Response response = await http.get(Uri.parse(url));
    List<dynamic> retorno = json.decode(response.body);
    repoNames.clear();
    repoUrls.clear();
    for (var repo in retorno) {
      repoNames.add(repo['name']);
      repoUrls.add(repo['html_url']);
    }
    setState(() {
      github_repos = retorno.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    Color appBarColor = Color(0xff160336);
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text("Perfil dos Devs")),
        backgroundColor: appBarColor,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: textController,
                      decoration: InputDecoration(
                        labelText: 'Digite o login do GitHub',
                      ),
                    ),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: appBarColor,
                    ),
                    onPressed: _getUserData,
                    child: Text('Encontrar DEV'),
                  ),
                ],
              ),
              SizedBox(height: 20),
              Card(
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.blueAccent,
                      width: 2.0,
                    ),
                  ),
                  child: ListTile(
                    leading: CachedNetworkImage(
                      imageUrl: github_avatar,
                      placeholder: (context, url) =>
                          CircularProgressIndicator(),
                      errorWidget: (context, url, error) => Icon(Icons.error),
                    ),
                    title: Text(github_nome),
                    subtitle: Text("Repositórios: $github_repos"),
                  ),
                ),
              ),
              ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: repoNames.length,
                itemBuilder: (context, index) {
                  return Card(
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.blueAccent,
                          width: 1.0,
                        ),
                      ),
                      child: ListTile(
                        title: Text(repoNames[index]),
                        subtitle: Text("URL: ${repoUrls[index]}"),
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
