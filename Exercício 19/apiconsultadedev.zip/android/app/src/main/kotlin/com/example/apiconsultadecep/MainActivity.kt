package com.example.apiconsultadecep

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
