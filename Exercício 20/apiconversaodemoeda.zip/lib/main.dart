import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(ConversorDeMoedasApp());

class ConversorDeMoedasApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Conversor de Moedas',
      theme: ThemeData(primaryColor: Color(0xff0f5793)),
      home: PaginaDoConversor(),
    );
  }
}

class PaginaDoConversor extends StatefulWidget {
  @override
  _PaginaDoConversorState createState() => _PaginaDoConversorState();
}

class _PaginaDoConversorState extends State<PaginaDoConversor> {
  final valorController = TextEditingController();
  String moedaDe = 'USD';
  String moedaPara = 'BRL';
  String? valorConvertido;

  Future<void> converterMoeda() async {
    final double valorEntrada = double.tryParse(valorController.text) ?? 0;

    final url =
        'https://economia.awesomeapi.com.br/json/last/$moedaDe-$moedaPara';
    final resposta = await http.get(Uri.parse(url));

    if (resposta.statusCode == 200) {
      final jsonResponse = json.decode(resposta.body);
      final taxaDeCambio =
          double.parse(jsonResponse['$moedaDe$moedaPara']['ask']);
      setState(() {
        valorConvertido = (valorEntrada * taxaDeCambio).toStringAsFixed(2);
      });
    } else {
      print('Erro ao acessar a API');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Conversor de Moedas'), centerTitle: true),
      body: Center(
        child: Container(
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.black, width: 1),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.network(
                'https://http2.mlstatic.com/D_NQ_NP_665726-MLB54882514251_042023-O.webp',
                width: 150,
                height: 150,
              ),
              SizedBox(height: 16.0),
              TextField(
                controller: valorController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Digite o valor',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              SizedBox(height: 10),
              DropdownButton<String>(
                value: moedaDe,
                items: ['USD', 'EUR', 'BTC'].map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    moedaDe = newValue!;
                  });
                },
              ),
              SizedBox(height: 10),
              DropdownButton<String>(
                value: moedaPara,
                items: ['BRL'].map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    moedaPara = newValue!;
                  });
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: converterMoeda,
                child: Text('Converter'),
                style: ElevatedButton.styleFrom(
                    primary: Color(0xff0f5793)), // Cor do botão
              ),
              SizedBox(height: 20),
              Text(
                'Valor convertido:',
                style: TextStyle(fontSize: 20),
              ),
              Text(
                valorConvertido ?? '---',
                style: TextStyle(fontSize: 24, color: Colors.red),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
