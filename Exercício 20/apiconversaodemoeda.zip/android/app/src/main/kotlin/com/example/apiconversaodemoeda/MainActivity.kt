package com.example.apiconversaodemoeda

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
