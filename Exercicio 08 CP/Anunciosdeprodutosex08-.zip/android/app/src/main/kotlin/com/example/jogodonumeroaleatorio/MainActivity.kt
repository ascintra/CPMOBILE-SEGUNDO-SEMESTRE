package com.example.jogodonumeroaleatorio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
