import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late SharedPreferences prefs;
  bool dia = false;
  bool pequeno = false;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    prefs = await SharedPreferences.getInstance();
    print('SharedPreferences obtida.');

    dia = prefs.getBool('dia') ?? false;
    pequeno = prefs.getBool('pequeno') ?? false;

    print('Preferências carregadas: dia = $dia, pequeno = $pequeno');
  }

  Future<void> _saveBool(String key, bool value) async {
    print('Salvando preferência $key: $value');
    bool success = await prefs.setBool(key, value);
    if (success) {
      print('Preferência $key salva com sucesso.');
    } else {
      print('Falha ao salvar preferência $key.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('FRASES DE EFEITO'),
          centerTitle: true,
          backgroundColor: Colors.black,
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text('Dia'),
                  Switch(
                    value: dia,
                    onChanged: (value) {
                      setState(() {
                        dia = value;
                        _saveBool('dia', dia);
                      });
                    },
                  ),
                  Text('Pequeno'),
                  Switch(
                    value: pequeno,
                    onChanged: (value) {
                      setState(() {
                        pequeno = value;
                        _saveBool('pequeno', pequeno);
                      });
                    },
                  ),
                ],
              ),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: dia ? Colors.white : Colors.black,
                    border: Border.all(
                        color: dia ? Colors.black : Colors.white, width: 3),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(
                    child: Text(
                      'A vingança nunca é plena, mata a alma e envenena!',
                      style: TextStyle(
                        color: dia ? Colors.black : Colors.white,
                        fontSize: pequeno ? 12 : 22,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
