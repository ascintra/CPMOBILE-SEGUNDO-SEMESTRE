import 'dart:convert';
import 'package:http/http.dart' as http;
import 'movie.dart';

class MovieApi {
  static Future<List<Movie>> getMovies() async {
    var uri = Uri.parse('https://sujeitoprogramador.com/r-api/?api=filmes');
    var response = await http.get(uri);
    var json = await jsonDecode(response.body);

    return json.map((item) => Movie.fromJson(item)).toList();
  }
}
