import 'package:flutter/material.dart';
import 'movie.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List<Movie> movies = [];

  void _fetchMovies() async {
    var response = await http
        .get(Uri.parse('https://sujeitoprogramador.com/r-api/?api=filmes'));
    if (response.statusCode == 200) {
      var body = json.decode(response.body);
      movies = body['movies'].map((movie) => Movie.fromJson(movie)).toList();
    } else {
      throw Exception('Erro ao carregar filmes');
    }
  }

  @override
  void initState() {
    super.initState();
    _fetchMovies();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Filmes'),
      ),
      body: ListView.builder(
        itemCount: movies.length,
        itemBuilder: (context, index) {
          var movie = movies[index];
          return ListTile(
            leading: Image.network(movie.foto),
            title: Text(movie.nome),
            subtitle: Text(movie.sinopse),
          );
        },
      ),
    );
  }
}
