import 'package:flutter/material.dart';
import 'movie.dart';

class Details extends StatelessWidget {
  final Movie movie;

  const Details({required this.movie}) : super();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(movie.nome),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Image.network(movie.foto),
            Text(movie.sinopse),
          ],
        ),
      ),
    );
  }
}
