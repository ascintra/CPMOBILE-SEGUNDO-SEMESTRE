class Movie {
  String id;
  String nome;
  String foto;
  String sinopse;

  Movie({
    required this.id,
    required this.nome,
    required this.foto,
    required this.sinopse,
  });

  factory Movie.fromJson(Map<String, dynamic> json) {
    return Movie(
      id: json['id'],
      nome: json['nome'],
      foto: json['foto'],
      sinopse: json['sinopse'],
    );
  }
}
